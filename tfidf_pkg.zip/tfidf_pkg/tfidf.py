#!/usr/bin/python
#Program to find tf-idf weight (term X doc) matrix
#Author: Manu Madhavan
#Email: mmnamboodiry@gmail.com
###Disclaimer
##This program does not consider stemming, and punctuation removal.
##TF is normalized by the count of highest freqent term in the document
##idf is caluclated as log(N/(1+n)) where N is the total no of docs and n is the number of docs in which term appears.
##intermediate results are written to seperate files.
##The corpus consists of documents seperated by new line.

import math

def newRow(n):
	row=[]
	for i in range(n):
		row.append(0)
	return row

def computeTFMatrix(docs):
	matrix={}
	for i in range(n):
		doc=docs[i]
		doc=doc.lower()
		d_terms=doc.split()
		for t in d_terms:
			if t not in terms:
				continue
			if t not in matrix:
				matrix[t]=newRow(n)
				matrix[t][i]=1
			else:
				matrix[t][i]=matrix[t][i]+1
	for i in range(n):
		maxfreq=max([matrix[t][i] for t in terms])
		for t in terms:
			matrix[t][i]=matrix[t][i]/float(maxfreq) 
	return matrix	

def computeIDF(docs): 
	matrix={}
	for w in terms:
		docfreq=sum([int(w in d.lower().split()) for d in docs])
		matrix[w]=math.log(float(n)/(1+docfreq))
	return matrix

		
def computeWeight(tf,idf):
	matrix={}
	for t in terms:
		matrix[t]=newRow(n)
		for i in range(n):
			matrix[t][i]=tf[t][i]*idf[t]
	return matrix

def writeMatrix(fname,matrix):
	fp=open(fname,"w")
	for w in terms:
		if type(matrix[w]) is list:
			str1=w+"\t"+"\t".join(str(i) for i in matrix[w])
		else:
			str1=w+"\t"+str(matrix[w])
		fp.write(str1)
		fp.write("\n")
	fp.close()

##################################******************************************************############################################

corpus="corpus.txt"
termfreq="termfreq.txt"
idf="idf.txt"
weight="term_weight.txt"

stopwords=open("stopwords.lst").read().split()

docs=open(corpus).read().split("\n")[:-1]
n=len(docs)
print "Total Number of Docs: ",n

#Punctions not removed
terms=[]
for d in docs:
	d=d.lower()
	terms=list(set(terms+d.split()))

#remove stop words
terms=[x for x in terms if x not in stopwords]

print "Total Number of terms: ",len(terms)

tfmatrix=computeTFMatrix(docs)
writeMatrix(termfreq,tfmatrix)

idfmatrix=computeIDF(docs)
writeMatrix(idf,idfmatrix)

weightmatrix=computeWeight(tfmatrix,idfmatrix)
writeMatrix(weight,weightmatrix)



